import unittest

from simulador_so.escalonador.fcfs import EscalonadorFCFS


class ThreadFalsa:
    """Dublê simples: só precisa se comportar como uma Thread para o
    escalonador, que apenas guarda e devolve referências."""

    def __init__(self, tid):
        self.tid = tid


class TesteEscalonadorFCFS(unittest.TestCase):
    def test_ordem_de_selecao_e_fifo(self):
        escalonador = EscalonadorFCFS()
        a, b, c = ThreadFalsa("A"), ThreadFalsa("B"), ThreadFalsa("C")

        escalonador.ao_ficar_pronta(a)
        escalonador.ao_ficar_pronta(b)
        escalonador.ao_ficar_pronta(c)

        self.assertIs(escalonador.selecionar_proxima(), a)
        self.assertIs(escalonador.selecionar_proxima(), b)
        self.assertIs(escalonador.selecionar_proxima(), c)

    def test_fila_vazia(self):
        escalonador = EscalonadorFCFS()
        self.assertTrue(escalonador.fila_vazia())
        self.assertIsNone(escalonador.selecionar_proxima())

        escalonador.ao_ficar_pronta(ThreadFalsa("A"))
        self.assertFalse(escalonador.fila_vazia())

    def test_nao_possui_quantum(self):
        escalonador = EscalonadorFCFS()
        self.assertIsNone(escalonador.quantum())


if __name__ == "__main__":
    unittest.main()

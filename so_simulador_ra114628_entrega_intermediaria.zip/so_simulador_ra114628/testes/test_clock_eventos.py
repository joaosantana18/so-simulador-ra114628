import unittest

from simulador_so.core.clock import Clock
from simulador_so.core.eventos import TipoEvento
from simulador_so.core.fila_eventos import FilaEventos


class TesteClock(unittest.TestCase):
    def test_avanca_corretamente(self):
        relogio = Clock()
        self.assertEqual(relogio.agora(), 0)
        relogio.avancar_para(5)
        self.assertEqual(relogio.agora(), 5)
        relogio.avancar_para(5)  # permanecer no mesmo instante é válido
        self.assertEqual(relogio.agora(), 5)

    def test_rejeita_retrocesso(self):
        relogio = Clock()
        relogio.avancar_para(10)
        with self.assertRaises(ValueError):
            relogio.avancar_para(3)


class TesteFilaEventos(unittest.TestCase):
    def test_ordena_por_tempo(self):
        fila = FilaEventos()
        fila.agendar(10, TipoEvento.CHEGADA, "A")
        fila.agendar(2, TipoEvento.CHEGADA, "B")
        fila.agendar(5, TipoEvento.CHEGADA, "C")

        tempos = [fila.proximo().tempo for _ in range(3)]
        self.assertEqual(tempos, [2, 5, 10])

    def test_desempate_por_ordem_de_agendamento(self):
        """Eventos no mesmo instante devem sair na ordem em que foram
        agendados, garantindo determinismo (mesma carga => mesmo resultado)."""
        fila = FilaEventos()
        fila.agendar(7, TipoEvento.CHEGADA, "primeiro")
        fila.agendar(7, TipoEvento.CHEGADA, "segundo")
        fila.agendar(7, TipoEvento.CHEGADA, "terceiro")

        alvos = [fila.proximo().id_alvo for _ in range(3)]
        self.assertEqual(alvos, ["primeiro", "segundo", "terceiro"])

    def test_fila_vazia(self):
        fila = FilaEventos()
        self.assertTrue(fila.vazia())
        fila.agendar(1, TipoEvento.CHEGADA, "X")
        self.assertFalse(fila.vazia())
        fila.proximo()
        self.assertTrue(fila.vazia())
        self.assertIsNone(fila.proximo())


if __name__ == "__main__":
    unittest.main()

import unittest

from simulador_so.core.clock import Clock
from simulador_so.core.registrador import RegistradorEventos
from simulador_so.excecoes import EstadoInvalidoError
from simulador_so.modelo.estados import EstadoProcesso, EstadoThread
from simulador_so.modelo.pcb import PCB
from simulador_so.modelo.processo import Processo
from simulador_so.modelo.tcb import TCB
from simulador_so.modelo.thread_ import Thread


def _thread_nova(tid="T1", pid="P1", rajadas=None):
    relogio = Clock()
    registrador = RegistradorEventos()
    tcb = TCB(tid=tid, pid=pid, rajadas=rajadas or [("CPU", 5)])
    return Thread(tcb, registrador, relogio), registrador, relogio


class TesteTransicoesThread(unittest.TestCase):
    def test_transicao_valida(self):
        thread, registrador, _ = _thread_nova()
        thread.transitar(EstadoThread.PRONTA, "chegada")
        self.assertEqual(thread.estado, EstadoThread.PRONTA)
        self.assertTrue(any("TRANSICAO_THREAD" in linha for linha in registrador.linhas()))

    def test_transicao_invalida_levanta_excecao(self):
        thread, _, _ = _thread_nova()
        with self.assertRaises(EstadoInvalidoError):
            thread.transitar(EstadoThread.EXECUTANDO, "pulo de estado indevido")

    def test_nao_ha_transicao_a_partir_de_finalizada(self):
        thread, _, _ = _thread_nova()
        thread.transitar(EstadoThread.PRONTA, "chegada")
        thread.transitar(EstadoThread.EXECUTANDO, "despacho")
        thread.transitar(EstadoThread.FINALIZADA, "fim das rajadas")
        with self.assertRaises(EstadoInvalidoError):
            thread.transitar(EstadoThread.PRONTA, "tentativa invalida")

    def test_rajadas_avancam_corretamente(self):
        thread, _, _ = _thread_nova(rajadas=[("CPU", 5), ("IO", 3), ("CPU", 2)])
        self.assertEqual(thread.rajada_atual(), ("CPU", 5))
        thread.avancar_rajada()
        self.assertEqual(thread.rajada_atual(), ("IO", 3))
        thread.avancar_rajada()
        self.assertEqual(thread.rajada_atual(), ("CPU", 2))
        thread.avancar_rajada()
        self.assertIsNone(thread.rajada_atual())


class TesteTransicoesProcesso(unittest.TestCase):
    def _processo_novo(self):
        relogio = Clock()
        registrador = RegistradorEventos()
        pcb = PCB(pid="P1", prioridade=1)
        processo = Processo(pcb, registrador, relogio)
        return processo, registrador

    def test_transicao_valida(self):
        processo, registrador = self._processo_novo()
        processo.transitar(EstadoProcesso.PRONTO, "primeira thread pronta")
        self.assertEqual(processo.pcb.estado, EstadoProcesso.PRONTO)
        self.assertTrue(any("TRANSICAO_PROCESSO" in linha for linha in registrador.linhas()))

    def test_transicao_invalida_levanta_excecao(self):
        processo, _ = self._processo_novo()
        with self.assertRaises(EstadoInvalidoError):
            processo.transitar(EstadoProcesso.FINALIZADO, "pulo indevido")

    def test_todas_threads_finalizadas(self):
        relogio = Clock()
        registrador = RegistradorEventos()
        pcb = PCB(pid="P1", prioridade=1)
        processo = Processo(pcb, registrador, relogio)

        tcb = TCB(tid="T1", pid="P1", rajadas=[("CPU", 1)])
        thread = Thread(tcb, registrador, relogio)
        processo.adicionar_thread(thread)

        self.assertFalse(processo.todas_threads_finalizadas())
        thread.transitar(EstadoThread.PRONTA, "chegada")
        thread.transitar(EstadoThread.EXECUTANDO, "despacho")
        thread.transitar(EstadoThread.FINALIZADA, "fim das rajadas")
        self.assertTrue(processo.todas_threads_finalizadas())


if __name__ == "__main__":
    unittest.main()

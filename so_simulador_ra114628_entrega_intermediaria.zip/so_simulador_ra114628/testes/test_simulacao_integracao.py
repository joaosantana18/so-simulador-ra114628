"""Teste de integração ponta a ponta.

Reproduz manualmente o mesmo cálculo da carga de verificação
(cargas/carga_verificacao.txt) para garantir que o simulador é
determinístico e que as métricas batem com o esperado à mão:

    T1;0;1;CPU:5
    T2;1;1;CPU:3
    custo_troca_contexto = 1

Traço esperado (sem E/S, apenas para validar o núcleo/escalonador):
    t=0  T1 chega, fica PRONTA, inicia troca de contexto (fim em t=1)
    t=1  T2 chega, fica PRONTA (CPU ocupada com a troca de T1)
    t=1  fim da troca de contexto de T1 -> T1 EXECUTANDO (rajada de 5)
    t=6  T1 termina a rajada -> FINALIZADA; inicia troca de contexto de T2 (fim em t=7)
    t=7  T2 EXECUTANDO (rajada de 3)
    t=10 T2 termina -> FINALIZADA

Métricas esperadas:
    T1: retorno=6-0=6   espera=1-0=1   resposta=1-0=1
    T2: retorno=10-1=9  espera=7-1=6   resposta=7-1=6
"""

import unittest

from simulador_so.carga.carregador import carregar_arquivo
from simulador_so.core.registrador import RegistradorEventos
from simulador_so.core.simulador import Simulador
from simulador_so.escalonador.fcfs import EscalonadorFCFS
from simulador_so.modelo.estados import EstadoProcesso, EstadoThread

CAMINHO_CARGA_VERIFICACAO = "cargas/carga_verificacao.txt"


class TesteSimulacaoIntegracao(unittest.TestCase):
    def _executar(self, custo_troca_contexto=1):
        especificacoes = carregar_arquivo(CAMINHO_CARGA_VERIFICACAO)
        registrador = RegistradorEventos()
        simulador = Simulador(EscalonadorFCFS(), custo_troca_contexto, registrador)
        simulador.carregar_processos(especificacoes)
        simulador.executar()
        return simulador

    def test_todas_as_threads_e_processos_finalizam(self):
        simulador = self._executar()
        for thread in simulador.threads.values():
            self.assertEqual(thread.estado, EstadoThread.FINALIZADA)
        for processo in simulador.processos.values():
            self.assertEqual(processo.pcb.estado, EstadoProcesso.FINALIZADO)

    def test_metricas_batem_com_o_calculo_manual(self):
        simulador = self._executar()
        metricas = simulador.gerar_metricas()
        por_tid = {linha["tid"]: linha for linha in metricas["threads"]}

        self.assertEqual(por_tid["T1"]["tempo_retorno"], 6)
        self.assertEqual(por_tid["T1"]["tempo_espera"], 1)
        self.assertEqual(por_tid["T1"]["tempo_resposta"], 1)

        self.assertEqual(por_tid["T2"]["tempo_retorno"], 9)
        self.assertEqual(por_tid["T2"]["tempo_espera"], 6)
        self.assertEqual(por_tid["T2"]["tempo_resposta"], 6)

        self.assertEqual(metricas["tempo_total_simulado"], 10)
        self.assertEqual(metricas["qtd_processos_finalizados"], 2)
        self.assertEqual(metricas["qtd_trocas_contexto"], 2)
        self.assertEqual(metricas["tempo_total_trocas_contexto"], 2)

    def test_determinismo_execucoes_repetidas_geram_o_mesmo_log(self):
        sim1 = self._executar()
        sim2 = self._executar()
        self.assertEqual(sim1.registrador.linhas(), sim2.registrador.linhas())

    def test_bloqueio_e_desbloqueio_por_entrada_e_saida(self):
        """Carga com uma rajada de E/S no meio, construída em memória para
        isolar o comportamento do dispositivo sem depender de arquivo."""
        especificacoes = [
            {"id": "T1", "chegada": 0, "prioridade": 1, "rajadas": [("CPU", 2), ("IO", 4), ("CPU", 1)]},
        ]
        registrador = RegistradorEventos()
        simulador = Simulador(EscalonadorFCFS(), custo_troca_contexto=1, registrador=registrador)
        simulador.carregar_processos(especificacoes)
        simulador.executar()

        thread = simulador.threads["T1"]
        self.assertEqual(thread.estado, EstadoThread.FINALIZADA)
        # t=0 chegada; t=1 fim troca ctx -> executando; t=3 fim rajada CPU (2) -> bloqueia por IO;
        # t=7 fim IO (4) -> pronta; t=8 fim troca ctx -> executando; t=9 fim rajada CPU (1) -> finalizada.
        self.assertEqual(thread.tcb.tempo_finalizacao, 9)
        self.assertEqual(simulador.dispositivo_io.qtd_atendimentos, 1)
        self.assertEqual(simulador.dispositivo_io.tempo_total_ocupado, 4)


if __name__ == "__main__":
    unittest.main()

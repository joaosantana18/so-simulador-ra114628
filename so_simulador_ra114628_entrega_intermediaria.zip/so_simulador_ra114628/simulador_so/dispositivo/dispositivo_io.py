"""Dispositivo de E/S com fila própria e atendimento FCFS.

Versão preliminar: um único dispositivo genérico. A entrega final deverá
diferenciar pelo menos um dispositivo de bloco e um de caractere, e poderá
comparar FCFS com SSTF/SCAN (aplicável a disco). A interface já isola a
política de atendimento do restante do núcleo, facilitando essa extensão.
"""

from collections import deque


class DispositivoIO:
    def __init__(self, nome):
        self.nome = nome
        self._fila = deque()
        self.ocupado = False
        self.tempo_total_ocupado = 0
        self.qtd_atendimentos = 0

    def enfileirar(self, thread, duracao):
        self._fila.append((thread, duracao))

    def proxima_requisicao(self):
        if not self._fila:
            return None
        return self._fila.popleft()

    def fila_vazia(self):
        return len(self._fila) == 0

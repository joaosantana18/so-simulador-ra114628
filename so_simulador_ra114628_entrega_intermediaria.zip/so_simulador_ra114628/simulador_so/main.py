"""Ponto de entrada da linha de comando do simulador.

Exemplo de uso:

    python -m simulador_so.main --carga cargas/carga_mista.txt \\
        --escalonador fcfs --custo-troca-contexto 1
"""

import argparse
import sys

from simulador_so.carga.carregador import carregar_arquivo
from simulador_so.core.registrador import RegistradorEventos
from simulador_so.core.simulador import Simulador
from simulador_so.escalonador.fcfs import EscalonadorFCFS
from simulador_so.excecoes import CargaInvalidaError

ESCALONADORES_DISPONIVEIS = {
    "fcfs": EscalonadorFCFS,
    # "rr" e "prioridades" estão previstos para a entrega final.
}


def construir_parser():
    parser = argparse.ArgumentParser(
        prog="simulador_so",
        description="Simulador didático de sistemas operacionais (entrega intermediária).",
    )
    parser.add_argument("--carga", required=True, help="caminho do arquivo de carga de trabalho")
    parser.add_argument(
        "--escalonador",
        default="fcfs",
        choices=sorted(ESCALONADORES_DISPONIVEIS.keys()),
        help="política de escalonamento da CPU (padrão: fcfs)",
    )
    parser.add_argument(
        "--custo-troca-contexto",
        type=int,
        default=1,
        help="custo, em unidades de clock, de cada troca de contexto (padrão: 1)",
    )
    parser.add_argument(
        "--tempo-io",
        type=int,
        default=None,
        help="se informado, sobrepõe a duração de TODAS as rajadas de E/S da carga",
    )
    parser.add_argument(
        "--semente",
        type=int,
        default=None,
        help="semente de aleatoriedade (reservada para geração futura de cargas; apenas registrada no log)",
    )
    parser.add_argument("--log-saida", default=None, help="arquivo onde salvar o log de eventos")
    return parser


def _validar_parametros(args):
    if args.custo_troca_contexto < 0:
        return "custo de troca de contexto não pode ser negativo"
    if args.tempo_io is not None and args.tempo_io <= 0:
        return "--tempo-io deve ser um inteiro positivo"
    return None


def _aplicar_sobreposicao_io(especificacoes, tempo_io):
    if tempo_io is None:
        return especificacoes
    for spec in especificacoes:
        spec["rajadas"] = [
            (tipo, tempo_io if tipo == "IO" else duracao) for tipo, duracao in spec["rajadas"]
        ]
    return especificacoes


def _imprimir_metricas(metricas):
    print()
    print("=== MÉTRICAS ===")
    print(f"{'thread':<10}{'retorno':>10}{'espera':>10}{'resposta':>10}")
    for linha in metricas["threads"]:
        print(
            f"{linha['tid']:<10}"
            f"{linha['tempo_retorno'] if linha['tempo_retorno'] is not None else '-':>10}"
            f"{linha['tempo_espera']:>10}"
            f"{linha['tempo_resposta'] if linha['tempo_resposta'] is not None else '-':>10}"
        )
    print()
    print(f"Tempo total simulado ......... {metricas['tempo_total_simulado']}")
    print(f"Utilização da CPU ............ {metricas['utilizacao_cpu']:.2%}")
    print(f"Utilização do dispositivo E/S . {metricas['utilizacao_dispositivo_io']:.2%}")
    print(f"Throughput (proc./unid.tempo). {metricas['throughput_processos_por_unidade_tempo']:.4f}")
    print(f"Trocas de contexto ............ {metricas['qtd_trocas_contexto']}")
    print(f"Tempo total em trocas de ctx... {metricas['tempo_total_trocas_contexto']}")
    print(f"Processos finalizados ......... {metricas['qtd_processos_finalizados']}")


def main(argv=None):
    parser = construir_parser()
    args = parser.parse_args(argv)

    erro_param = _validar_parametros(args)
    if erro_param is not None:
        print(f"Parâmetro inválido: {erro_param}")
        return 1

    try:
        especificacoes = carregar_arquivo(args.carga)
    except CargaInvalidaError as erro:
        print(f"Erro na carga de trabalho: {erro}")
        return 1

    especificacoes = _aplicar_sobreposicao_io(especificacoes, args.tempo_io)

    registrador = RegistradorEventos()
    registrador.registrar(
        0,
        "CONFIGURACAO",
        "-",
        f"carga={args.carga} escalonador={args.escalonador} "
        f"custo_troca_contexto={args.custo_troca_contexto} tempo_io={args.tempo_io} "
        f"semente={args.semente}",
    )

    escalonador = ESCALONADORES_DISPONIVEIS[args.escalonador]()
    simulador = Simulador(escalonador, args.custo_troca_contexto, registrador)
    simulador.carregar_processos(especificacoes)
    simulador.executar()

    if args.log_saida:
        registrador.salvar(args.log_saida)
        print(f"Log de eventos salvo em: {args.log_saida}")
    else:
        registrador.imprimir()

    metricas = simulador.gerar_metricas()
    _imprimir_metricas(metricas)
    return 0


if __name__ == "__main__":
    sys.exit(main())

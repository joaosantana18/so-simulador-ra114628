"""Exceções específicas do domínio do simulador."""


class EstadoInvalidoError(Exception):
    """Levantada quando uma transição de estado não é permitida pelo modelo.

    O enunciado do trabalho exige que toda mudança de estado ocorra por um
    evento identificável. Uma transição direta sem causa registrada (ou uma
    transição que não faz sentido, como ir de FINALIZADA para EXECUTANDO)
    deve ser tratada como falha do modelo, e não silenciosamente ignorada.
    """


class CargaInvalidaError(Exception):
    """Levantada quando o arquivo de carga de trabalho é inválido.

    Cobre campos ausentes, tipos incorretos, identificadores duplicados e
    sequências de rajadas mal formadas.
    """

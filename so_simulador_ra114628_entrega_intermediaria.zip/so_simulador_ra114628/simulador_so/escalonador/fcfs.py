"""Escalonador FCFS (First-Come, First-Served).

Política obrigatória mínima para a entrega intermediária: não preemptiva,
seleciona sempre a thread que está há mais tempo na fila de prontos (ordem
de chegada à fila).
"""

from collections import deque

from simulador_so.escalonador.base import EscalonadorBase


class EscalonadorFCFS(EscalonadorBase):
    def __init__(self):
        self._fila = deque()

    def ao_ficar_pronta(self, thread):
        self._fila.append(thread)

    def selecionar_proxima(self):
        if not self._fila:
            return None
        return self._fila.popleft()

    def fila_vazia(self):
        return len(self._fila) == 0

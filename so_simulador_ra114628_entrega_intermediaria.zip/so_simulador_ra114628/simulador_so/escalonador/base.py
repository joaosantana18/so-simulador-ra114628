"""Interface do escalonador de CPU.

A política de escalonamento é um componente substituível: o núcleo da
simulação depende apenas desta interface, nunca de uma implementação
concreta. Isso permite trocar FCFS por Round Robin ou prioridades (ambos
previstos para a entrega final) sem alterar o núcleo do simulador.
"""

from abc import ABC, abstractmethod


class EscalonadorBase(ABC):
    @abstractmethod
    def ao_ficar_pronta(self, thread):
        """Insere uma thread que acabou de ficar pronta na estrutura interna."""

    @abstractmethod
    def selecionar_proxima(self):
        """Remove e retorna a próxima thread a ser despachada, ou None."""

    @abstractmethod
    def fila_vazia(self):
        """Indica se não há threads prontas aguardando a CPU."""

    def quantum(self):
        """Quantum de tempo da política, ou None se não houver preempção
        por tempo (caso do FCFS)."""
        return None

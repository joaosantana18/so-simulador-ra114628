"""Fila de eventos futuros, base do simulador orientado a eventos discretos.

O desempate entre eventos agendados para o mesmo instante do clock lógico
é feito pela ordem de agendamento (um contador monotônico crescente), o que
implementa a regra determinística "ordem de chegada seguida pelo
identificador" pedida no enunciado: o evento agendado primeiro é sempre
processado primeiro quando os tempos coincidem, garantindo que a mesma
carga e a mesma configuração produzam sempre o mesmo resultado.
"""

import heapq
from itertools import count

from simulador_so.core.eventos import Evento


class FilaEventos:
    def __init__(self):
        self._heap = []
        self._contador = count()

    def agendar(self, tempo, tipo, id_alvo, dados=None):
        evento = Evento(
            tempo=tempo,
            sequencia=next(self._contador),
            tipo=tipo,
            id_alvo=id_alvo,
            dados=dados or {},
        )
        heapq.heappush(self._heap, evento)
        return evento

    def proximo(self):
        if not self._heap:
            return None
        return heapq.heappop(self._heap)

    def vazia(self):
        return len(self._heap) == 0

    def __len__(self):
        return len(self._heap)

"""Tipos de evento do simulador e a estrutura de dados Evento.

Eventos adicionais (falta de página, abertura/fechamento de arquivo, fim de
quantum) serão incluídos nas etapas de memória, arquivos e escalonamento
por Round Robin/prioridades, previstas para a entrega final.
"""

from dataclasses import dataclass, field
from enum import Enum, auto


class TipoEvento(Enum):
    CHEGADA = auto()
    FIM_TROCA_CONTEXTO = auto()
    FIM_RAJADA_CPU = auto()
    CONCLUSAO_IO = auto()


@dataclass(order=True)
class Evento:
    tempo: int
    sequencia: int
    tipo: TipoEvento = field(compare=False)
    id_alvo: str = field(compare=False)
    dados: dict = field(default_factory=dict, compare=False)

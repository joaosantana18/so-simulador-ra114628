"""Clock lógico.

O tempo é representado por um inteiro abstrato, avançado apenas quando o
núcleo da simulação processa o próximo evento da fila. Isso garante que o
resultado não dependa da velocidade da máquina que executa o programa.
"""


class Clock:
    def __init__(self):
        self._tempo_atual = 0

    def agora(self):
        return self._tempo_atual

    def avancar_para(self, novo_tempo):
        if novo_tempo < self._tempo_atual:
            raise ValueError(
                f"o clock lógico não pode retroceder: atual={self._tempo_atual}, "
                f"solicitado={novo_tempo}"
            )
        self._tempo_atual = novo_tempo

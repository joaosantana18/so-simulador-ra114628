"""Núcleo da simulação.

Coordena o clock lógico e a fila de eventos, delegando decisões de
política (qual thread executar em seguida) ao escalonador injetado. O
núcleo não conhece FCFS, Round Robin ou prioridades: apenas chama os
métodos da interface EscalonadorBase. Isso mantém mecanismo e política
separados, como pedido na especificação.

Fluxo de eventos implementado nesta etapa:

    CHEGADA -> (fila de prontos) -> FIM_TROCA_CONTEXTO -> FIM_RAJADA_CPU
        -> [BLOQUEIO por E/S -> CONCLUSAO_IO -> fila de prontos] ou
           [FINALIZAÇÃO da thread/processo]
"""

from simulador_so.core.clock import Clock
from simulador_so.core.eventos import TipoEvento
from simulador_so.core.fila_eventos import FilaEventos
from simulador_so.core.registrador import RegistradorEventos
from simulador_so.dispositivo.dispositivo_io import DispositivoIO
from simulador_so.modelo.estados import EstadoProcesso, EstadoThread
from simulador_so.modelo.pcb import PCB
from simulador_so.modelo.processo import Processo
from simulador_so.modelo.tcb import TCB
from simulador_so.modelo.thread_ import Thread


class Simulador:
    def __init__(self, escalonador, custo_troca_contexto, registrador=None):
        if custo_troca_contexto < 0:
            raise ValueError("custo de troca de contexto não pode ser negativo")

        self.relogio = Clock()
        self.fila_eventos = FilaEventos()
        self.escalonador = escalonador
        self.custo_troca_contexto = custo_troca_contexto
        self.registrador = registrador or RegistradorEventos()

        self.dispositivo_io = DispositivoIO("disp0")

        self.processos = {}
        self.threads = {}

        self.cpu_ocupada = False
        self.qtd_trocas_contexto = 0
        self.tempo_total_trocas_contexto = 0
        self.qtd_processos_finalizados = 0

    # ------------------------------------------------------------------
    # Carga de trabalho
    # ------------------------------------------------------------------
    def carregar_processos(self, especificacoes):
        for spec in especificacoes:
            pcb = PCB(pid=spec["id"], prioridade=spec["prioridade"], instante_criacao=spec["chegada"])
            processo = Processo(pcb, self.registrador, self.relogio)

            tcb = TCB(tid=spec["id"], pid=spec["id"], rajadas=spec["rajadas"], tempo_chegada=spec["chegada"])
            thread = Thread(tcb, self.registrador, self.relogio)

            processo.adicionar_thread(thread)
            self.processos[pcb.pid] = processo
            self.threads[tcb.tid] = thread

            self.fila_eventos.agendar(spec["chegada"], TipoEvento.CHEGADA, tcb.tid)

    # ------------------------------------------------------------------
    # Laço principal
    # ------------------------------------------------------------------
    def executar(self):
        while not self.fila_eventos.vazia():
            evento = self.fila_eventos.proximo()
            self.relogio.avancar_para(evento.tempo)
            self._tratar_evento(evento)
        self.registrador.registrar(self.relogio.agora(), "FIM_SIMULACAO", "-", "fila de eventos vazia")

    def _tratar_evento(self, evento):
        manipuladores = {
            TipoEvento.CHEGADA: self._ao_chegar,
            TipoEvento.FIM_TROCA_CONTEXTO: self._ao_fim_troca_contexto,
            TipoEvento.FIM_RAJADA_CPU: self._ao_fim_rajada_cpu,
            TipoEvento.CONCLUSAO_IO: self._ao_concluir_io,
        }
        manipuladores[evento.tipo](evento)

    # ------------------------------------------------------------------
    # Manipuladores de evento
    # ------------------------------------------------------------------
    def _ao_chegar(self, evento):
        thread = self.threads[evento.id_alvo]
        processo = self.processos[thread.tcb.pid]

        if processo.pcb.estado == EstadoProcesso.NOVO:
            processo.transitar(EstadoProcesso.PRONTO, "primeira thread do processo ficou pronta")

        thread.transitar(EstadoThread.PRONTA, "chegada registrada na carga de trabalho")
        thread.tcb.marca_entrada_fila = self.relogio.agora()
        self.escalonador.ao_ficar_pronta(thread)
        self.registrador.registrar(
            self.relogio.agora(), "CHEGADA", f"thread={thread.tcb.tid}", "thread entrou na fila de prontos"
        )
        self._tentar_despachar()

    def _tentar_despachar(self):
        if self.cpu_ocupada:
            return
        proxima = self.escalonador.selecionar_proxima()
        if proxima is None:
            return

        self.cpu_ocupada = True
        inicio = self.relogio.agora()
        fim = inicio + self.custo_troca_contexto
        self.qtd_trocas_contexto += 1
        self.tempo_total_trocas_contexto += self.custo_troca_contexto

        self.registrador.registrar(
            inicio,
            "INICIO_TROCA_CTX",
            f"thread={proxima.tcb.tid}",
            f"custo de troca de contexto = {self.custo_troca_contexto}",
        )
        self.fila_eventos.agendar(fim, TipoEvento.FIM_TROCA_CONTEXTO, proxima.tcb.tid)

    def _ao_fim_troca_contexto(self, evento):
        thread = self.threads[evento.id_alvo]

        if thread.tcb.marca_entrada_fila is not None:
            thread.tcb.tempo_espera_acumulado += self.relogio.agora() - thread.tcb.marca_entrada_fila
            thread.tcb.marca_entrada_fila = None
        if thread.tcb.tempo_primeiro_despacho is None:
            thread.tcb.tempo_primeiro_despacho = self.relogio.agora()

        thread.transitar(EstadoThread.EXECUTANDO, "fim da troca de contexto, despacho para a CPU")

        processo = self.processos[thread.tcb.pid]
        if processo.pcb.estado != EstadoProcesso.EXECUTANDO:
            processo.transitar(EstadoProcesso.EXECUTANDO, "thread do processo foi despachada")

        self.registrador.registrar(
            self.relogio.agora(), "DESPACHO", f"thread={thread.tcb.tid}", "thread iniciou execução na CPU"
        )

        tipo, duracao = thread.rajada_atual()
        assert tipo == "CPU", "thread despachada sem rajada de CPU corrente"
        self.fila_eventos.agendar(self.relogio.agora() + duracao, TipoEvento.FIM_RAJADA_CPU, thread.tcb.tid)

    def _ao_fim_rajada_cpu(self, evento):
        thread = self.threads[evento.id_alvo]
        thread.avancar_rajada()
        proxima_rajada = thread.rajada_atual()

        self.cpu_ocupada = False

        if proxima_rajada is None:
            thread.transitar(EstadoThread.FINALIZADA, "todas as rajadas da thread foram concluídas")
            thread.tcb.tempo_finalizacao = self.relogio.agora()
            self.registrador.registrar(
                self.relogio.agora(), "FIM_THREAD", f"thread={thread.tcb.tid}", "thread finalizada"
            )

            processo = self.processos[thread.tcb.pid]
            if processo.todas_threads_finalizadas():
                processo.transitar(EstadoProcesso.FINALIZADO, "todas as threads do processo finalizaram")
                self.qtd_processos_finalizados += 1
                self.registrador.registrar(
                    self.relogio.agora(),
                    "FIM_PROCESSO",
                    f"processo={processo.pcb.pid}",
                    "processo finalizado",
                )
        else:
            tipo, duracao = proxima_rajada
            if tipo == "IO":
                thread.transitar(EstadoThread.BLOQUEADA, "solicitação de operação de E/S")
                self.registrador.registrar(
                    self.relogio.agora(),
                    "BLOQUEIO",
                    f"thread={thread.tcb.tid}",
                    f"solicitou E/S por {duracao} unidades",
                )
                self._solicitar_io(thread, duracao)
            else:  # pragma: no cover - defensivo; carregador impede CPU->CPU
                thread.transitar(EstadoThread.PRONTA, "nova rajada de CPU disponível")
                thread.tcb.marca_entrada_fila = self.relogio.agora()
                self.escalonador.ao_ficar_pronta(thread)

        self._tentar_despachar()

    def _solicitar_io(self, thread, duracao):
        dispositivo = self.dispositivo_io
        estava_ocioso = dispositivo.fila_vazia() and not dispositivo.ocupado
        dispositivo.enfileirar(thread, duracao)
        if estava_ocioso:
            self._iniciar_proximo_io()

    def _iniciar_proximo_io(self):
        dispositivo = self.dispositivo_io
        requisicao = dispositivo.proxima_requisicao()
        if requisicao is None:
            dispositivo.ocupado = False
            return

        thread, duracao = requisicao
        dispositivo.ocupado = True
        dispositivo.tempo_total_ocupado += duracao
        dispositivo.qtd_atendimentos += 1
        self.registrador.registrar(
            self.relogio.agora(),
            "INICIO_IO",
            f"thread={thread.tcb.tid}",
            f"dispositivo={dispositivo.nome} duracao={duracao}",
        )
        self.fila_eventos.agendar(self.relogio.agora() + duracao, TipoEvento.CONCLUSAO_IO, thread.tcb.tid)

    def _ao_concluir_io(self, evento):
        thread = self.threads[evento.id_alvo]
        thread.transitar(EstadoThread.PRONTA, "conclusão da operação de E/S (interrupção simulada)")
        thread.avancar_rajada()
        thread.tcb.marca_entrada_fila = self.relogio.agora()

        self.registrador.registrar(
            self.relogio.agora(), "CONCLUSAO_IO", f"thread={thread.tcb.tid}", "E/S concluída, thread pronta"
        )
        self.escalonador.ao_ficar_pronta(thread)

        self.dispositivo_io.ocupado = False
        self._iniciar_proximo_io()
        self._tentar_despachar()

    # ------------------------------------------------------------------
    # Métricas
    # ------------------------------------------------------------------
    def gerar_metricas(self):
        tempo_total = self.relogio.agora()
        linhas_threads = []
        tempo_cpu_util = 0

        for thread in self.threads.values():
            tcb = thread.tcb
            tempo_cpu_util += sum(dur for tipo, dur in tcb.rajadas if tipo == "CPU")

            retorno = None
            resposta = None
            if tcb.tempo_finalizacao is not None:
                retorno = tcb.tempo_finalizacao - tcb.tempo_chegada
            if tcb.tempo_primeiro_despacho is not None:
                resposta = tcb.tempo_primeiro_despacho - tcb.tempo_chegada

            linhas_threads.append(
                {
                    "tid": tcb.tid,
                    "tempo_retorno": retorno,
                    "tempo_espera": tcb.tempo_espera_acumulado,
                    "tempo_resposta": resposta,
                }
            )

        utilizacao_cpu = (tempo_cpu_util / tempo_total) if tempo_total > 0 else 0.0
        utilizacao_dispositivo = (
            self.dispositivo_io.tempo_total_ocupado / tempo_total if tempo_total > 0 else 0.0
        )
        throughput = (self.qtd_processos_finalizados / tempo_total) if tempo_total > 0 else 0.0

        return {
            "threads": linhas_threads,
            "tempo_total_simulado": tempo_total,
            "utilizacao_cpu": utilizacao_cpu,
            "utilizacao_dispositivo_io": utilizacao_dispositivo,
            "throughput_processos_por_unidade_tempo": throughput,
            "qtd_trocas_contexto": self.qtd_trocas_contexto,
            "tempo_total_trocas_contexto": self.tempo_total_trocas_contexto,
            "qtd_processos_finalizados": self.qtd_processos_finalizados,
        }

"""Registrador de eventos: mantém o log textual da simulação.

Cada linha contém o valor do clock, o tipo do evento, os objetos
envolvidos e uma descrição concisa, conforme pedido na especificação.
"""


class RegistradorEventos:
    def __init__(self):
        self._linhas = []

    def registrar(self, tempo, tipo, objetos, descricao):
        linha = f"[{tempo:06d}] {tipo:<20} | {objetos:<18} | {descricao}"
        self._linhas.append(linha)

    def linhas(self):
        return list(self._linhas)

    def imprimir(self):
        for linha in self._linhas:
            print(linha)

    def salvar(self, caminho):
        with open(caminho, "w", encoding="utf-8") as arquivo:
            arquivo.write("\n".join(self._linhas))
            arquivo.write("\n")

"""Estados do ciclo de vida de processos e threads do simulador.

As tabelas de transição existem para que uma mudança de estado inválida
seja detectada imediatamente (levantando EstadoInvalidoError) em vez de
corromper silenciosamente o modelo, conforme exigido na especificação:
"Uma transição direta sem causa registrada será considerada falha do
modelo."
"""

from enum import Enum


class EstadoProcesso(Enum):
    NOVO = "NOVO"
    PRONTO = "PRONTO"
    EXECUTANDO = "EXECUTANDO"
    BLOQUEADO = "BLOQUEADO"
    FINALIZADO = "FINALIZADO"


class EstadoThread(Enum):
    NOVA = "NOVA"
    PRONTA = "PRONTA"
    EXECUTANDO = "EXECUTANDO"
    BLOQUEADA = "BLOQUEADA"
    FINALIZADA = "FINALIZADA"


# Transições permitidas para processos.
TRANSICOES_VALIDAS_PROCESSO = {
    EstadoProcesso.NOVO: {EstadoProcesso.PRONTO},
    EstadoProcesso.PRONTO: {EstadoProcesso.EXECUTANDO},
    EstadoProcesso.EXECUTANDO: {
        EstadoProcesso.PRONTO,
        EstadoProcesso.BLOQUEADO,
        EstadoProcesso.FINALIZADO,
    },
    EstadoProcesso.BLOQUEADO: {EstadoProcesso.PRONTO},
    EstadoProcesso.FINALIZADO: set(),
}

# Transições permitidas para threads.
TRANSICOES_VALIDAS_THREAD = {
    EstadoThread.NOVA: {EstadoThread.PRONTA},
    EstadoThread.PRONTA: {EstadoThread.EXECUTANDO},
    EstadoThread.EXECUTANDO: {
        EstadoThread.PRONTA,
        EstadoThread.BLOQUEADA,
        EstadoThread.FINALIZADA,
    },
    EstadoThread.BLOQUEADA: {EstadoThread.PRONTA},
    EstadoThread.FINALIZADA: set(),
}

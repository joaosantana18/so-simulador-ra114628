"""Classe Thread: encapsula o TCB e expõe operações sobre as rajadas."""

from simulador_so.excecoes import EstadoInvalidoError
from simulador_so.modelo.estados import TRANSICOES_VALIDAS_THREAD


class Thread:
    def __init__(self, tcb, registrador, relogio):
        self.tcb = tcb
        self._registrador = registrador
        self._relogio = relogio

    @property
    def estado(self):
        return self.tcb.estado

    def transitar(self, novo_estado, motivo):
        atual = self.tcb.estado
        permitidos = TRANSICOES_VALIDAS_THREAD.get(atual, set())
        if novo_estado not in permitidos:
            raise EstadoInvalidoError(
                f"thread {self.tcb.tid}: transição inválida de "
                f"{atual.value} para {novo_estado.value} (motivo: {motivo})"
            )
        self.tcb.estado = novo_estado
        self._registrador.registrar(
            self._relogio.agora(),
            "TRANSICAO_THREAD",
            f"thread={self.tcb.tid}",
            f"{atual.value} -> {novo_estado.value} ({motivo})",
        )

    def rajada_atual(self):
        """Retorna a rajada (tipo, duracao) corrente, ou None se esgotadas."""
        if self.tcb.indice_rajada >= len(self.tcb.rajadas):
            return None
        return self.tcb.rajadas[self.tcb.indice_rajada]

    def avancar_rajada(self):
        self.tcb.indice_rajada += 1

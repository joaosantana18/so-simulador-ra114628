"""PCB (Process Control Block) simplificado.

Concentra as informações administrativas do processo. Os campos
`espaco_enderecamento` e `tabela_arquivos_abertos` já existem na estrutura
porque farão parte da gerência de memória e do sistema de arquivos na
entrega final, mas não são utilizados nesta etapa intermediária.
"""

from dataclasses import dataclass, field

from simulador_so.modelo.estados import EstadoProcesso


@dataclass
class PCB:
    pid: str
    prioridade: int
    estado: EstadoProcesso = EstadoProcesso.NOVO
    instante_criacao: int = 0
    contador_programa: int = 0
    registradores: dict = field(default_factory=dict)
    threads: list = field(default_factory=list)  # tids pertencentes ao processo

    # Reservado para etapas futuras (gerência de memória / arquivos).
    espaco_enderecamento: object = None
    tabela_arquivos_abertos: dict = field(default_factory=dict)

"""Classe Processo: encapsula o PCB e coordena suas threads."""

from simulador_so.excecoes import EstadoInvalidoError
from simulador_so.modelo.estados import EstadoThread, TRANSICOES_VALIDAS_PROCESSO


class Processo:
    def __init__(self, pcb, registrador, relogio):
        self.pcb = pcb
        self._registrador = registrador
        self._relogio = relogio
        self._threads = []

    def adicionar_thread(self, thread):
        self._threads.append(thread)
        self.pcb.threads.append(thread.tcb.tid)

    @property
    def threads(self):
        return list(self._threads)

    def todas_threads_finalizadas(self):
        return len(self._threads) > 0 and all(
            t.estado == EstadoThread.FINALIZADA for t in self._threads
        )

    def transitar(self, novo_estado, motivo):
        atual = self.pcb.estado
        permitidos = TRANSICOES_VALIDAS_PROCESSO.get(atual, set())
        if novo_estado not in permitidos:
            raise EstadoInvalidoError(
                f"processo {self.pcb.pid}: transição inválida de "
                f"{atual.value} para {novo_estado.value} (motivo: {motivo})"
            )
        self.pcb.estado = novo_estado
        self._registrador.registrar(
            self._relogio.agora(),
            "TRANSICAO_PROCESSO",
            f"processo={self.pcb.pid}",
            f"{atual.value} -> {novo_estado.value} ({motivo})",
        )

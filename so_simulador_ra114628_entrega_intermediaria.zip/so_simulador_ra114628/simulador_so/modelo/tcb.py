"""TCB (Thread Control Block) simplificado.

Além dos campos clássicos (identificador, estado, PC, registradores,
pilha lógica), o TCB guarda a sequência de rajadas de CPU/E-S da tarefa e
alguns carimbos de tempo usados para calcular as métricas exigidas pelo
trabalho (tempo de retorno, de espera e de resposta).
"""

from dataclasses import dataclass, field

from simulador_so.modelo.estados import EstadoThread


@dataclass
class TCB:
    tid: str
    pid: str
    estado: EstadoThread = EstadoThread.NOVA
    pc: int = 0
    registradores: dict = field(default_factory=dict)
    pilha: list = field(default_factory=list)

    # Sequência de rajadas: lista de tuplas ("CPU"|"IO", duracao).
    rajadas: list = field(default_factory=list)
    indice_rajada: int = 0

    # Carimbos de tempo para métricas (preenchidos pelo núcleo da simulação).
    tempo_chegada: int = 0
    tempo_primeiro_despacho: int = None
    tempo_finalizacao: int = None
    tempo_espera_acumulado: int = 0
    marca_entrada_fila: int = None

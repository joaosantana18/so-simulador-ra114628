"""Leitura e validação do arquivo externo de carga de trabalho.

Formato textual (um processo por linha, campos separados por ';'):

    id;instante_chegada;prioridade;rajadas

`rajadas` é uma lista separada por vírgulas de pares "TIPO:duracao", onde
TIPO é CPU ou IO, começando sempre em CPU e alternando (nunca duas rajadas
do mesmo tipo em sequência). Linhas em branco e linhas iniciadas por '#'
são ignoradas.

Exemplo:
    P1;0;2;CPU:5,IO:3,CPU:2

A carga é sempre externa ao código-fonte: para simular outro cenário basta
apontar --carga para outro arquivo, sem recompilar nada.
"""

from simulador_so.excecoes import CargaInvalidaError

_TIPOS_VALIDOS = ("CPU", "IO")


def carregar_arquivo(caminho):
    especificacoes = []
    ids_vistos = set()
    try:
        arquivo = open(caminho, encoding="utf-8")
    except OSError as erro:
        raise CargaInvalidaError(f"não foi possível abrir o arquivo de carga '{caminho}': {erro}")

    with arquivo:
        for numero_linha, linha_bruta in enumerate(arquivo, start=1):
            linha = linha_bruta.strip()
            if not linha or linha.startswith("#"):
                continue
            especificacoes.append(_processar_linha(linha, numero_linha, ids_vistos))

    if not especificacoes:
        raise CargaInvalidaError(f"arquivo de carga '{caminho}' está vazio ou não possui tarefas válidas")

    return especificacoes


def _processar_linha(linha, numero_linha, ids_vistos):
    partes = linha.split(";")
    if len(partes) != 4:
        raise CargaInvalidaError(
            f"linha {numero_linha}: esperado 4 campos separados por ';' (id;chegada;prioridade;rajadas)"
        )
    id_bruto, chegada_str, prioridade_str, rajadas_str = (p.strip() for p in partes)

    if not id_bruto:
        raise CargaInvalidaError(f"linha {numero_linha}: identificador vazio")
    if id_bruto in ids_vistos:
        raise CargaInvalidaError(f"linha {numero_linha}: identificador duplicado '{id_bruto}'")
    ids_vistos.add(id_bruto)

    try:
        chegada = int(chegada_str)
    except ValueError:
        raise CargaInvalidaError(f"linha {numero_linha}: instante de chegada deve ser inteiro")
    if chegada < 0:
        raise CargaInvalidaError(f"linha {numero_linha}: instante de chegada não pode ser negativo")

    try:
        prioridade = int(prioridade_str)
    except ValueError:
        raise CargaInvalidaError(f"linha {numero_linha}: prioridade deve ser inteira")

    rajadas = _processar_rajadas(rajadas_str, numero_linha)

    return {"id": id_bruto, "chegada": chegada, "prioridade": prioridade, "rajadas": rajadas}


def _processar_rajadas(texto, numero_linha):
    itens = [item.strip() for item in texto.split(",") if item.strip()]
    if not itens:
        raise CargaInvalidaError(f"linha {numero_linha}: sequência de rajadas vazia")

    rajadas = []
    for item in itens:
        if ":" not in item:
            raise CargaInvalidaError(f"linha {numero_linha}: rajada mal formatada '{item}' (use TIPO:duracao)")
        tipo_str, duracao_str = item.split(":", 1)
        tipo = tipo_str.strip().upper()
        if tipo not in _TIPOS_VALIDOS:
            raise CargaInvalidaError(f"linha {numero_linha}: tipo de rajada inválido '{tipo}' (use CPU ou IO)")
        try:
            duracao = int(duracao_str.strip())
        except ValueError:
            raise CargaInvalidaError(f"linha {numero_linha}: duração de rajada inválida '{duracao_str}'")
        if duracao <= 0:
            raise CargaInvalidaError(f"linha {numero_linha}: duração de rajada deve ser positiva")
        rajadas.append((tipo, duracao))

    if rajadas[0][0] != "CPU":
        raise CargaInvalidaError(f"linha {numero_linha}: a sequência de rajadas deve começar com CPU")

    for i in range(1, len(rajadas)):
        if rajadas[i][0] == rajadas[i - 1][0]:
            raise CargaInvalidaError(
                f"linha {numero_linha}: rajadas do mesmo tipo não podem ser consecutivas"
            )

    return rajadas

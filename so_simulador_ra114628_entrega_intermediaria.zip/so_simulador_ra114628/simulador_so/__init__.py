"""Simulador didático de sistemas operacionais.

Trabalho da disciplina de Sistemas Operacionais.
Aluno: João Guilherme da Silva Santana (RA 114628)
Etapa: entrega intermediária
"""

# Arquitetura

## Visão geral

O simulador é orientado a eventos discretos: o tempo é um clock lógico
(`core/clock.py`), avançado apenas quando o núcleo (`core/simulador.py`)
retira o próximo evento de uma fila de prioridade (`core/fila_eventos.py`).
Não há relação com o relógio real da máquina.

```
carga/carregador.py            (lê e valida o arquivo externo de carga)
        │
        ▼
core/simulador.py  ── usa ──▶  core/clock.py
        │                       core/fila_eventos.py
        │                       core/registrador.py
        │
        ├── delega política ──▶ escalonador/base.py (interface)
        │                              └── escalonador/fcfs.py
        │
        ├── delega E/S ───────▶ dispositivo/dispositivo_io.py
        │
        └── mantém instâncias de:
                modelo/processo.py  (encapsula modelo/pcb.py)
                modelo/thread_.py   (encapsula modelo/tcb.py)
```

## Separação entre mecanismo e política

O núcleo (`Simulador`) nunca decide *qual* thread executar: ele apenas
pergunta ao escalonador (`EscalonadorBase.selecionar_proxima()`). Trocar de
FCFS para Round Robin ou prioridades, na entrega final, significará apenas
implementar uma nova subclasse de `EscalonadorBase` e passá-la para o
construtor de `Simulador` — nenhuma linha do núcleo muda.

O mesmo princípio guiará a política de atendimento do dispositivo de E/S
(hoje FCFS embutido em `DispositivoIO`) e, futuramente, a política de
substituição de página.

## Máquina de estados

`modelo/estados.py` define os estados e, mais importante, as **tabelas de
transições válidas** para processo e para thread. Toda mudança de estado
passa por `Processo.transitar()` / `Thread.transitar()`, que:

1. Verifica se a transição é permitida (levanta `EstadoInvalidoError` caso
   contrário — nenhuma transição "muda" o estado sem essa checagem);
2. Aplica a mudança;
3. Registra a transição no log com o motivo (o evento que a causou).

Isso implementa diretamente a exigência do enunciado de que toda mudança
de estado ocorra por um evento identificável e seja registrada.

## Fluxo de eventos implementado

```
CHEGADA
  └─▶ thread NOVA->PRONTA, entra no escalonador
       └─▶ se CPU livre: inicia troca de contexto
             └─▶ FIM_TROCA_CONTEXTO: thread PRONTA->EXECUTANDO
                    └─▶ agenda FIM_RAJADA_CPU (duração da rajada de CPU)
                           ├─▶ se próxima rajada é IO: thread EXECUTANDO->BLOQUEADA,
                           │     entra na fila do dispositivo
                           │       └─▶ CONCLUSAO_IO: thread BLOQUEADA->PRONTA,
                           │             volta ao escalonador
                           └─▶ se não há mais rajadas: thread EXECUTANDO->FINALIZADA;
                                 se todas as threads do processo finalizaram,
                                 processo ->FINALIZADO
```

Após qualquer evento que libere a CPU (fim de rajada) ou que insira uma
thread pronta (chegada, fim de E/S), o núcleo tenta despachar a próxima
thread (`_tentar_despachar`), respeitando o custo configurável de troca de
contexto.

## Determinismo

Dois mecanismos garantem que a mesma carga, configuração e (quando houver
aleatoriedade) semente produzam sempre o mesmo resultado:

1. O clock lógico só avança processando eventos da fila — nunca por
   tempo real.
2. Empates de horário na fila de eventos são resolvidos por um contador
   monotônico de agendamento (`itertools.count()` em `FilaEventos`), o que
   equivale a "ordem de chegada" determinística. Isso é conferido no teste
   `test_desempate_por_ordem_de_agendamento` e no teste de integração
   `test_determinismo_execucoes_repetidas_geram_o_mesmo_log`.

## O que ainda é um objeto "de mentira" (mecanismo, não SO real)

Processos e threads do simulador são objetos Python comuns — não são
processos/threads reais do sistema operacional hospedeiro. Não há
paralelismo real nem chamadas de sistema; a "CPU" é apenas uma variável de
estado (`Simulador.cpu_ocupada`) manipulada pelo núcleo.

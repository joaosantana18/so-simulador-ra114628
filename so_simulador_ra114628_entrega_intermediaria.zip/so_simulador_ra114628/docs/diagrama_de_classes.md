# Diagrama de classes (preliminar — entrega intermediária)

Este diagrama reflete o código desta etapa. Classes de memória (tabela de
páginas, moldura) e de sistema de arquivos (FCB, diretório) ainda não
existem no código e por isso não aparecem aqui; serão adicionadas no
diagrama da entrega final.

```mermaid
classDiagram
    class Clock {
        -int _tempo_atual
        +agora() int
        +avancar_para(novo_tempo)
    }

    class FilaEventos {
        -list _heap
        -count _contador
        +agendar(tempo, tipo, id_alvo, dados) Evento
        +proximo() Evento
        +vazia() bool
    }

    class Evento {
        +int tempo
        +int sequencia
        +TipoEvento tipo
        +str id_alvo
        +dict dados
    }

    class TipoEvento {
        <<enumeration>>
        CHEGADA
        FIM_TROCA_CONTEXTO
        FIM_RAJADA_CPU
        CONCLUSAO_IO
    }

    class RegistradorEventos {
        -list _linhas
        +registrar(tempo, tipo, objetos, descricao)
        +imprimir()
        +salvar(caminho)
    }

    class Simulador {
        +Clock relogio
        +FilaEventos fila_eventos
        +EscalonadorBase escalonador
        +int custo_troca_contexto
        +DispositivoIO dispositivo_io
        +dict processos
        +dict threads
        +bool cpu_ocupada
        +carregar_processos(especificacoes)
        +executar()
        +gerar_metricas() dict
        -_ao_chegar(evento)
        -_tentar_despachar()
        -_ao_fim_troca_contexto(evento)
        -_ao_fim_rajada_cpu(evento)
        -_ao_concluir_io(evento)
    }

    class EscalonadorBase {
        <<interface>>
        +ao_ficar_pronta(thread)
        +selecionar_proxima() Thread
        +fila_vazia() bool
        +quantum() int
    }

    class EscalonadorFCFS {
        -deque _fila
    }

    class DispositivoIO {
        +str nome
        -deque _fila
        +bool ocupado
        +int tempo_total_ocupado
        +int qtd_atendimentos
        +enfileirar(thread, duracao)
        +proxima_requisicao() tuple
        +fila_vazia() bool
    }

    class PCB {
        +str pid
        +int prioridade
        +EstadoProcesso estado
        +int instante_criacao
        +int contador_programa
        +dict registradores
        +list threads
        +object espaco_enderecamento
        +dict tabela_arquivos_abertos
    }

    class Processo {
        +PCB pcb
        +adicionar_thread(thread)
        +todas_threads_finalizadas() bool
        +transitar(novo_estado, motivo)
    }

    class TCB {
        +str tid
        +str pid
        +EstadoThread estado
        +int pc
        +dict registradores
        +list pilha
        +list rajadas
        +int indice_rajada
        +int tempo_chegada
        +int tempo_primeiro_despacho
        +int tempo_finalizacao
        +int tempo_espera_acumulado
    }

    class Thread {
        +TCB tcb
        +estado EstadoThread
        +transitar(novo_estado, motivo)
        +rajada_atual() tuple
        +avancar_rajada()
    }

    class EstadoProcesso {
        <<enumeration>>
        NOVO
        PRONTO
        EXECUTANDO
        BLOQUEADO
        FINALIZADO
    }

    class EstadoThread {
        <<enumeration>>
        NOVA
        PRONTA
        EXECUTANDO
        BLOQUEADA
        FINALIZADA
    }

    class CarregadorCarga {
        <<module>>
        +carregar_arquivo(caminho) list
    }

    Simulador "1" o-- "1" Clock
    Simulador "1" o-- "1" FilaEventos
    Simulador "1" o-- "1" RegistradorEventos
    Simulador "1" o-- "1" DispositivoIO
    Simulador "1" o-- "1" EscalonadorBase
    Simulador "1" o-- "*" Processo
    Simulador "1" o-- "*" Thread
    Simulador ..> CarregadorCarga : usa
    FilaEventos "1" *-- "*" Evento
    Evento --> TipoEvento
    EscalonadorBase <|-- EscalonadorFCFS
    Processo "1" *-- "1" PCB
    Processo "1" o-- "1..*" Thread
    Thread "1" *-- "1" TCB
    PCB --> EstadoProcesso
    TCB --> EstadoThread
```

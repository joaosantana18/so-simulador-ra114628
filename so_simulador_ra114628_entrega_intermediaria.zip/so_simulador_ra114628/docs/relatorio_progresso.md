# Relatório de progresso — Entrega intermediária

**Disciplina:** Sistemas Operacionais — Prof. Maurício Acconcia Dias
**Aluno:** João Guilherme da Silva Santana — **RA 114628**
**Organização:** individual
**Linguagem:** Python 3 (escolhida por oferecer orientação a objetos
completa — classes, herança, classes abstratas via `abc` — com sintaxe
enxuta, sem necessidade de compilação nem de gerenciador de dependências
para o escopo deste trabalho).

## 1. Funcionalidades concluídas nesta etapa

- **Núcleo de simulação orientado a eventos discretos**: clock lógico
  (`Clock`), fila de eventos por prioridade (`FilaEventos`) com desempate
  determinístico por ordem de agendamento, e o laço principal em
  `Simulador.executar()`.
- **Processos e threads**: `PCB`/`Processo` e `TCB`/`Thread` completos,
  com máquina de estados validada por tabelas de transição (`NOVO/NOVA →
  PRONTO/A → EXECUTANDO → BLOQUEADO/A → FINALIZADO/A`). Uma transição fora
  da tabela levanta `EstadoInvalidoError` em vez de ser aceita
  silenciosamente.
- **Escalonamento de CPU**: interface `EscalonadorBase` (substituível) e
  implementação obrigatória mínima **FCFS**, não preemptiva, com fila
  FIFO. Troca de contexto com custo configurável, contabilizada
  separadamente da CPU útil.
- **Bloqueio por E/S (versão preliminar)**: um dispositivo genérico
  (`DispositivoIO`) com fila FCFS já permite que uma thread seja bloqueada
  ao solicitar E/S e volte à fila de prontos quando o atendimento termina
  (evento `CONCLUSAO_IO`, análogo a uma interrupção simulada). Isso foi
  adiantado porque o núcleo de eventos já precisava manipular bloqueio e
  desbloqueio para ficar completo, mas o subsistema de E/S ainda é
  simplificado (ver limitações).
- **Carga de trabalho externa**: `carga/carregador.py` lê e valida um
  arquivo textual (formato documentado no `README.md`), rejeitando
  arquivos malformados com mensagem objetiva e sem corromper a execução.
  Três cargas de exemplo já estão no repositório (`carga_cpu_bound.txt`,
  `carga_io_bound.txt`, `carga_mista.txt`), além de uma carga pequena de
  verificação manual.
- **Log de eventos**: cada linha registra clock, tipo de evento, objetos
  envolvidos e descrição (chegada, transições de estado, despacho, início
  e fim de troca de contexto, bloqueio, conclusão de E/S, finalização).
- **Métricas básicas**: tempo de retorno, tempo de espera e tempo de
  resposta por thread; utilização da CPU e do dispositivo de E/S;
  throughput; quantidade e tempo total de trocas de contexto. O cálculo
  já é feito a partir do clock lógico, de forma uniforme.
- **Interface de linha de comando**: seleção de carga, escalonador, custo
  de troca de contexto, sobreposição do tempo de E/S e arquivo de log de
  saída. Parâmetros inválidos são detectados e a execução é encerrada com
  mensagem objetiva (testado manualmente com custo negativo, carga
  inexistente e carga malformada).
- **Testes automatizados** (19 testes, `unittest` da biblioteca padrão,
  sem dependências externas): clock e fila de eventos, transições de
  estado de processo/thread, ordem de seleção do FCFS, e um teste de
  integração ponta a ponta que reproduz **manualmente** o cálculo das
  métricas esperadas para a carga de verificação e confirma
  determinismo entre execuções repetidas (mesmo log byte a byte).
- **Diagrama de classes preliminar** e descrição da arquitetura
  (`docs/diagrama_de_classes.md`, `docs/arquitetura.md`), coerentes com o
  código desta entrega.

## 2. Percentual estimado de conclusão

Estimativa em relação ao escopo total da entrega final:

| Módulo                                   | Situação                          | Estimativa |
|-------------------------------------------|-----------------------------------|:----------:|
| Núcleo (clock, eventos, log)              | Concluído                         | ~95%       |
| Processos e threads (PCB/TCB, estados)    | Concluído para o escopo atual     | ~90%       |
| Escalonamento de CPU                      | FCFS pronto; RR e prioridades faltam | ~35%    |
| Entrada e saída                           | Um dispositivo genérico FCFS; faltam bloco/caractere separados e SSTF/SCAN | ~25% |
| Gerência de memória (paginação)           | Não iniciada                       | 0%         |
| Sistema de arquivos                       | Não iniciada                       | 0%         |
| Testes automatizados                      | Base sólida para o que existe; crescerá com cada módulo novo | ~40% do total final |
| Documentação (README, arquitetura, diagrama) | Em dia com o código atual       | ~100% do que já existe |
| Experimentos do relatório final           | Não iniciados (dependem dos módulos acima) | 0% |

**Percentual global estimado da entrega final: aproximadamente 30–35%.**

## 3. Limitações conhecidas nesta etapa

- Apenas a política **FCFS** está implementada. Round Robin (quantum
  configurável) e escalonamento por prioridades (com decisão sobre
  preempção) ainda não existem, embora a interface `EscalonadorBase` já
  esteja pronta para recebê-los sem alterar o núcleo.
- O subsistema de E/S tem **um único dispositivo genérico**, sem
  diferenciar dispositivo de bloco e de caractere, e sem políticas
  alternativas (SSTF/SCAN). A duração de cada operação de E/S vem
  diretamente da carga de trabalho (ou é sobreposta globalmente por
  `--tempo-io`); não há ainda um tempo de serviço configurável por
  dispositivo.
- **Não há gerência de memória**: paginação, tabela de páginas, faltas de
  página e substituição FIFO ainda não foram implementadas.
- **Não há sistema de arquivos**: diretórios, FCB/nó-i, descritores e
  operações de arquivo ainda não foram implementados.
- O modelo de `Processo` atual foi simplificado para processos com uma
  thread (o que a especificação permite explicitamente para cargas
  simples). A sincronização de estado do processo quando várias de suas
  threads bloqueiam/desbloqueiam de forma independente ainda não foi
  exercitada em teste e será revisada ao dar suporte completo a
  múltiplas threads por processo.
- Não há geração aleatória de cargas ainda; por isso o parâmetro
  `--semente` só é registrado no log, sem efeito sobre a simulação.
- Os três experimentos exigidos no relatório técnico final (comparação de
  políticas de escalonamento, efeito do quantum, e memória ou E/S) ainda
  não foram realizados, pois dependem de Round Robin/prioridades e de
  paginação, respectivamente.

## 4. Plano para a entrega final

1. Implementar `EscalonadorRoundRobin` (com quantum configurável e evento
   de fim de quantum) e `EscalonadorPrioridades` (decidindo e documentando
   se será preemptivo), reaproveitando a interface `EscalonadorBase`.
2. Expandir o subsistema de E/S: pelo menos um dispositivo de bloco e um
   de caractere, tempos de serviço configuráveis por dispositivo, e uma
   operação não bloqueante (sem espera ativa). Implementar SSTF/SCAN para
   o dispositivo de bloco e o experimento comparativo pedido.
3. Implementar a gerência de memória por paginação: espaço de
   endereçamento por processo, tabela de páginas, eventos de falta de
   página e substituição FIFO (LRU/Clock como extensão opcional).
4. Implementar o sistema de arquivos hierárquico: diretórios, FCB
   simplificado, tabela global de arquivos abertos, descritores por
   processo e as operações mínimas exigidas (criar, abrir, ler, escrever,
   fechar, remover, listar), com detecção de operações inválidas.
5. Ampliar os testes automatizados para cobrir cada novo módulo (fim de
   quantum, tradução de endereço, falta de página, validação de
   operações de arquivo), mantendo a mesma abordagem de conferência
   manual usada no teste de integração atual.
6. Rodar e documentar os três experimentos exigidos, mantendo constantes
   os parâmetros que não estiverem sob análise em cada comparação.
7. Atualizar o diagrama de classes e o README para refletir os novos
   módulos, e escrever o relatório técnico final em PDF.

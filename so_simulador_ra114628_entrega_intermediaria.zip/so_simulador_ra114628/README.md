# Simulador didático de sistemas operacionais

Disciplina de Sistemas Operacionais — Prof. Maurício Acconcia Dias
Aluno: **João Guilherme da Silva Santana** — RA **114628**
Organização: individual
Etapa entregue neste pacote: **entrega intermediária**

## 1. Requisitos

- Python 3.9 ou superior (não há dependências externas: só biblioteca padrão).
- Sistema operacional qualquer (Linux, macOS, Windows) com Python instalado.

## 2. Instalação

Não há instalação nem compilação: é um projeto Python puro.

```bash
git clone <url-do-repositorio>
cd so_simulador_ra114628
```

## 3. Execução

A partir da raiz do projeto:

```bash
python3 -m simulador_so.main --carga cargas/carga_mista.txt
```

O comando acima usa o escalonador FCFS (única política implementada nesta
etapa) e custo de troca de contexto igual a 1. Todos os parâmetros:

| Parâmetro                  | Obrigatório | Padrão | Descrição                                                                 |
|-----------------------------|:-----------:|:------:|----------------------------------------------------------------------------|
| `--carga`                  | sim         | —      | Caminho do arquivo de carga de trabalho (ver formato abaixo).              |
| `--escalonador`             | não         | fcfs   | Política de escalonamento. Nesta etapa só `fcfs` está disponível.         |
| `--custo-troca-contexto`    | não         | 1      | Custo, em unidades de clock, de cada troca de contexto.                    |
| `--tempo-io`                | não         | —      | Se informado, sobrepõe a duração de **todas** as rajadas de E/S da carga. |
| `--semente`                 | não         | —      | Semente de aleatoriedade; reservada para geração futura de cargas. Apenas registrada no log nesta etapa (não há geração aleatória ainda). |
| `--log-saida <arquivo>`     | não         | —      | Salva o log de eventos no arquivo indicado; se omitido, imprime no terminal. |

Parâmetros inválidos (custo negativo, `--tempo-io` não positivo, carga
inexistente ou malformada) produzem uma mensagem objetiva no terminal e
encerram a execução com código de saída 1, sem gerar log parcial.

### Exemplos

```bash
# Execução simples, log no terminal
python3 -m simulador_so.main --carga cargas/carga_cpu_bound.txt

# Troca de contexto mais cara, log salvo em arquivo
python3 -m simulador_so.main --carga cargas/carga_io_bound.txt \
    --custo-troca-contexto 2 --log-saida saida.log

# Sobrepondo o tempo de E/S de toda a carga para 4 unidades
python3 -m simulador_so.main --carga cargas/carga_mista.txt --tempo-io 4
```

## 4. Formato do arquivo de carga de trabalho

Um processo (com uma única thread) por linha, campos separados por `;`:

```
id;instante_chegada;prioridade;rajadas
```

- `id`: identificador único da tarefa (texto, sem `;`).
- `instante_chegada`: inteiro ≥ 0.
- `prioridade`: inteiro (usado apenas quando o escalonador por prioridades
  for implementado, na entrega final; por ora é apenas armazenado no PCB).
- `rajadas`: lista separada por vírgulas de pares `TIPO:duracao`, em que
  `TIPO` é `CPU` ou `IO`. A sequência **deve começar em `CPU`** e alternar
  (nunca duas rajadas do mesmo tipo em seguida).

Linhas em branco e linhas iniciadas por `#` são ignoradas (usadas para
comentários). Exemplo:

```
# id;chegada;prioridade;rajadas
P1;0;2;CPU:4,IO:3,CPU:4
P2;0;1;CPU:6
```

O arquivo é sempre externo ao código-fonte: para simular outro cenário
basta apontar `--carga` para outro arquivo, sem alterar nem recompilar
nada.

### Cargas incluídas no repositório

| Arquivo                          | Perfil                                   |
|-----------------------------------|-------------------------------------------|
| `cargas/carga_verificacao.txt`   | Carga mínima (2 tarefas, só CPU) usada para conferência manual — ver `docs/relatorio_progresso.md`. |
| `cargas/carga_cpu_bound.txt`     | Predominantemente limitada por CPU.        |
| `cargas/carga_io_bound.txt`      | Predominantemente limitada por E/S.        |
| `cargas/carga_mista.txt`         | Mistura equilibrada de CPU e E/S.          |

## 5. Testes automatizados

Os testes usam apenas `unittest` da biblioteca padrão (nenhuma dependência
externa). Para rodar todos, a partir da raiz do projeto:

```bash
python3 -m unittest discover -s testes -v
```

Resultado esperado: **19 testes, todos com `ok`**, terminando em `OK`.

Os testes cobrem:
- `testes/test_clock_eventos.py`: avanço/retrocesso do clock lógico;
  ordenação da fila de eventos e desempate determinístico por ordem de
  agendamento.
- `testes/test_modelo.py`: transições válidas e inválidas de estado de
  processo e de thread; avanço da sequência de rajadas.
- `testes/test_escalonador_fcfs.py`: ordem de seleção FIFO do escalonador.
- `testes/test_simulacao_integracao.py`: simulação completa ponta a ponta,
  incluindo conferência manual das métricas (tempo de retorno, de espera e
  de resposta) para a carga de verificação, determinismo entre execuções
  repetidas, e bloqueio/desbloqueio por E/S.

## 6. Estrutura do repositório

```
so_simulador_ra114628/
├── simulador_so/          # código-fonte
│   ├── core/               # clock, eventos, fila de eventos, log, núcleo
│   ├── modelo/             # estados, PCB, TCB, Processo, Thread
│   ├── escalonador/        # interface + política FCFS
│   ├── dispositivo/        # dispositivo de E/S genérico
│   ├── carga/              # leitura/validação do arquivo de carga
│   ├── excecoes.py
│   └── main.py             # linha de comando
├── cargas/                 # arquivos de carga de trabalho de exemplo
├── testes/                 # testes automatizados (unittest)
├── docs/                   # arquitetura, diagrama de classes, relatório
└── README.md
```

## 7. Limitações conhecidas desta etapa (ver `docs/relatorio_progresso.md`)

Escalonamento por Round Robin e por prioridades, gerência de memória
(paginação/faltas de página), sistema de arquivos e múltiplos dispositivos
de E/S diferenciados (bloco/caractere) ainda **não** estão implementados
nesta entrega intermediária. Detalhes, percentual estimado e plano para a
entrega final estão em `docs/relatorio_progresso.md`.
